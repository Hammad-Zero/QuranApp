import 'package:flutter/material.dart';

Color background = const Color(0xFF040C23);
Color text = const Color(0xFFA19CC5);
Color orange = const Color(0xFFF9B091);
Color primary = const Color(0xFFA44AFF);
Color gray = const Color(0xFF121931);
