import 'package:flutter/material.dart';

class ParaTab extends StatelessWidget {
  const ParaTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
